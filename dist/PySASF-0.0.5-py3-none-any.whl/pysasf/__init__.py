__all__ = ["basindata", 
           "clarkeminella", 
           "distances", 
           "plots",
           "readers",
           "solvers",
           "stats",
           "utils"]
